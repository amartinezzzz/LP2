﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] vet = new int[9, 10];
            char[] respostas = { 'A', 'E', 'C', 'B', 'A', 'D', 'B', 'E', 'C', 'D' };
            string aux = "";

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aux = Interaction.InputBox($"Digite a resposta do {i+1}º aluno da {j + 1}º questão: ",
                        "Entrada de respostas");
                    if ((Convert.ToChar(aux) != 'A') && (Convert.ToChar(aux) != 'B') &&
                        (Convert.ToChar(aux)) != 'C' && (Convert.ToChar(aux) != 'D') &&
                        (Convert.ToChar(aux)) != 'E')
                    {
                        MessageBox.Show("As respostas válidas são: A, B, C, D ou E.");
                        j--;
                    }
                    else
                    {
                        if ((Convert.ToChar(aux.ToUpper())) == respostas[j])
                            listBox1.Items.Add($"O aluno {i + 1} acertou a questão {j + 1}," +
                                $" era {respostas[j]} e escolheu {aux.ToUpper()}");
                        else
                        {
                            listBox1.Items.Add($"O aluno {i + 1} errou a questão {j + 1}," +
                                $" era {respostas[j]} e escolheu {aux.ToUpper()}");
                        }
                    }
                }
            }
        }
    }
}
