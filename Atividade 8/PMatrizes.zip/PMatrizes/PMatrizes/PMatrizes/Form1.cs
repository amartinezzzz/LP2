﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vet = new int[20];
            string aux = "";
            string saida = "";

            for (int i= 0; i < vet.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de dados");
                if (aux == "")
                    break;
                if (!int.TryParse(aux, out vet[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida = aux + "\n" + saida; 
                }
            }

            Array.Reverse(vet);
            aux = "";
            foreach (int i in vet)
            {
                aux += i + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() {"Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", 
                "Marcelo", "Pedro", "Thais"};
            alunos.Remove("Otávio");
            string str = string.Join(", ", alunos.ToArray());
            MessageBox.Show($"Os nomes: {str}");
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string aux = "";
            double[] media = new double[20];
            double soma = 0;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a {j + 1}º nota do {i + 1}º aluno", "Entrada de notas");
                    if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida");
                        j--;

                    }
                    else
                    {
                        soma += notas[i, j];
                    }
                }
                media[i] = soma / 3;
                soma = 0;
            }
            for (int i = 0; i < 20; i++)
                MessageBox.Show("A média do aluno " + $"{i + 1}" + " é: " + media[i].ToString("N1"));
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj1 = new frmExercicio4();
                obj1.WindowState = FormWindowState.Normal;
                obj1.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj1 = new frmExercicio5();
                obj1.WindowState = FormWindowState.Normal;
                obj1.Show();
            }
        }
    }
}
