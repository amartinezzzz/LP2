﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] caracs = new int[10];
            string aux = "";

            for (int i = 0; i < nomes.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º nome: ", "Entrada da dados");
                nomes[i] = aux;
                caracs[i] = aux.Replace(" ", "").Length;
            }
            for (int i = 0;i < nomes.Length;i++)
            {
                listBox1.Items.Add($"O nome: {nomes[i]} tem {caracs[i]} caracteres");
            }
        }
    }
}