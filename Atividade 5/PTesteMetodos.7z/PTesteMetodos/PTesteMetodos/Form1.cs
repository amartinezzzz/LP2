﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercício2"].BringToFront();
            }
            else
            {
                frmExercício2 objExercicio2 = new frmExercício2();
                objExercicio2.MdiParent = this;
                objExercicio2.WindowState = FormWindowState.Maximized;
                objExercicio2.Show();
            }
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O texto foi colado");
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercício3"].BringToFront();
            }
            else
            {
                frmExercício3 objExercicio3 = new frmExercício3();
                objExercicio3.MdiParent = this;
                objExercicio3.WindowState = FormWindowState.Maximized;
                objExercicio3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercício4"].BringToFront();
            }
            else
            {
                frmExercício4 objExercicio4 = new frmExercício4();
                objExercicio4.MdiParent = this;
                objExercicio4.WindowState = FormWindowState.Maximized;
                objExercicio4.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercício5"].BringToFront();
            }
            else
            {
                frmExercício5 objExercicio5 = new frmExercício5();
                objExercicio5.MdiParent = this;
                objExercicio5.WindowState = FormWindowState.Maximized;
                objExercicio5.Show();
            }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O texto foi copiado");
        }
    }
}
