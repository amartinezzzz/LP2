﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (var i=0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break;
                }
            }
            if (posicao == -1)
            {
                MessageBox.Show("Não existe espaço em branco");
            }
            else
                MessageBox.Show($"Posição do 1º caracter em branco: {posicao}");
        }

        private void btnContaNumeros_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.Text.Length;
            int contaNum = 0;
            int i = 0;
            while(i < tamanho)
            {
                if (Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contaNum++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {contaNum}");
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.Text.Length;
            int contaLetras = 0;
            int i = 0;
            while(i < tamanho)
            {
                if (Char.IsLetter(rchtxtFrase.Text[i]))
                {
                    contaLetras++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras: {contaLetras}");
        }
    }
}
