﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercício5 : Form
    {
        public frmExercício5()
        {
            InitializeComponent();
        }

        private void frmExercício5_Load(object sender, EventArgs e)
        {

        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2;
            if (!int.TryParse(txtNumero1.Text, out num1)|| !int.TryParse(txtNumero2.Text, out num2)
                || num1 < 0 || num2 < 0 || num2 < num1)
            {
                MessageBox.Show("Números inválidos");
                txtNumero1.Focus();
            }
            else
            {
                Random objAleatorio = new Random();
                Double sorteio = objAleatorio.Next(num1, num2);
                MessageBox.Show("O número sorteado: " + sorteio);
            }
        }
    }
}
