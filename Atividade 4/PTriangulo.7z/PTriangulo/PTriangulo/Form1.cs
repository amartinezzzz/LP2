﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorB.Text, out b) || b <= 0)
            {
                MessageBox.Show("Escreva um número válido.");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorC.Text, out c)|| c <= 0)
            {
                MessageBox.Show("Escreva um número válido.");
                txtValorC.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if ((a < b + c) && (a > Math.Abs(b - c)) && (b < a + c) && (b > Math.Abs(a - c))
                && (c < a + b) && (c > Math.Abs(a - b)))
            {
                if (((a == b) && (a != c)) || ((a == c) && (a != b)) ||
                    ((b == c) && (b != a)))
                {
                    MessageBox.Show("São valores de um triângulo isósceles.");
                }
                else if ((a == b) && (a == c))
                {
                    MessageBox.Show("É um triângulo equilátero.");
                }
                else
                    MessageBox.Show("É um triângulo escaleno.");
            }
            else
                MessageBox.Show("Não é possível transformar em triângulo.");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = string.Empty;
            txtValorB.Text = string.Empty;
            txtValorC.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorA.Text, out a)|| a <= 0){
                MessageBox.Show("Escreva um número válido.");
                txtValorA.Focus();
            }
        }
    }
}
