﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void txtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFrase_Validating(object sender, CancelEventArgs e)
        {
            int tamanho = txtFrase.Text.Length;
            if (tamanho > 50)
            {
                MessageBox.Show("A frase deve ter no máximo 50 letras.");
                txtFrase.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string str = txtFrase.Text.ToString().ToUpper();
            str = str.Replace(" ", "");
            char[] inverter = str.ToCharArray();
            Array.Reverse(inverter);
            string str2 = new string(inverter);
            if(String.Compare(str, str2, true) == 0)
            {
                MessageBox.Show($"A frase '{txtFrase.Text}' é um palíndromo");
            }
            else
                MessageBox.Show($"A frase '{txtFrase.Text}' não é um palíndromo");
        }
    }
}
