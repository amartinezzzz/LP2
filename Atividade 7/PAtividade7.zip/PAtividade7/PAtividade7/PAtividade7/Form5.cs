﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int prod = Convert.ToInt32(txtProducao.Text);
            double gratif = Convert.ToDouble(txtGratificacao.Text);
            double salario= Convert.ToDouble(txtSalario.Text);
            double salarioBruto;
            double b, c, d;

            if (prod >= 100)
                b = 1;
            else
                b = 0;
            if (prod >= 120)
                c = 1;
            else
                c = 0;
            if (prod >= 150)
                d = 1;
            else
                d = 0;
            salarioBruto = salario + salario * (0.05 * b + 0.1 * c + 0.1 * d) + gratif;
            if (salarioBruto > 7000)
            {
                if (prod < 150 || gratif == 0)
                    MessageBox.Show("O Salário Bruto não pode ser maior que R$7000,00");
                else
                    MessageBox.Show($"O Salário Bruto é: R${salarioBruto}");
            }
            else
                MessageBox.Show($"O Salário Bruto é: R${salarioBruto}");
        }
    }
}
