﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int prod = Convert.ToInt32(txtProducao.Text);
            double gratif = Convert.ToDouble(txtGratificacao.Text);
            double salario= Convert.ToDouble(txtSalario.Text);
            double salarioBruto;
            double b, c, d;

            if (prod >= 100)
                b = 1;
            else
                b = 0;
            if (prod >= 120)
                c = 1;
            else
                c = 0;
            if (prod >= 150)
                d = 1;
            else
                d = 0;
            salarioBruto = salario + salario * (0.05 * b + 0.1 * c + 0.1 * d) + gratif;
            if (salarioBruto > 7000)
            {
                if (prod < 150 || gratif == 0)
                    MessageBox.Show("O Salário Bruto é limitado a R$7000,00");
                else
                    MessageBox.Show($"O Salário Bruto é: R${salarioBruto}");
            }
            else
                MessageBox.Show($"O Salário Bruto é: R${salarioBruto}");
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            int prod;
            if (!int.TryParse(txtProducao.Text, out prod) || prod < 0)
            {
                MessageBox.Show("A produção deve conter um número inteiro.");
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            double salario = Convert.ToDouble(txtSalario.Text);
            if(salario <= 0)
            {
                MessageBox.Show("O salário deve ser maior que zero.");
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            double gratif = Convert.ToDouble(txtGratificacao.Text);
            if (gratif < 0)
            {
                MessageBox.Show("A gratificação deve ser maior ou igual a zero.");
                txtGratificacao.Focus();
            }
        }
    }
}
