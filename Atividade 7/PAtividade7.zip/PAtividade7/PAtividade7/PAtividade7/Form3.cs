﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtN_Validating(object sender, CancelEventArgs e)
        {
            int n;
            if (!int.TryParse(txtN.Text, out n)|| n <= 0)
            {
                MessageBox.Show("Digite um número maior que zero.");
                txtN.Focus();
            }
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            double n = Convert.ToInt32(txtN.Text);
            double h = 0, i;
            for (i = 1; i <= n; i++)
            {
                h += 1 / i;
            }
            MessageBox.Show($"O valor de H é: {h}");
        }
    }
}
