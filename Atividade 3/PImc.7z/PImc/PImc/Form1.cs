﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inválida");
                e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtImc.Text = imc.ToString();
            if (imc < 18.5)
                MessageBox.Show("Classificação: Magreza. Obesidade grau 0.");
            else if (imc < 24.9)
                MessageBox.Show("Classificação: Normal. Obesidade grau 0.");
            else if (imc < 29.9)
                MessageBox.Show("Classificação: Sobrepeso. Obesidade grau 1.");
            else if (imc < 39.9)
                MessageBox.Show("Classificação: Obesidade. Grau: 2.");
            else
                MessageBox.Show("Classificação: Obesidade Grave. Grau: 3.");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = string.Empty;
            mskbxAltura.Text = string.Empty;
            txtImc.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                e.Cancel = true;
            }
        }
    }
}
